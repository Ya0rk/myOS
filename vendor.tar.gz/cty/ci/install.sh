set -ex

main() {
    return
}

main
